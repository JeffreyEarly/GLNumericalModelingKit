These are the binaries for netCDF 4.1.2.
For this build: CC=cc CXX=g++ FC=gfortran F77=gfortran 90=
CFLAGS=-g -m32 CXXFLAGS=-g -m32
FCFLAGS=-g -m32 F77FLAGS=-g -m32 90FLAGS=
